// import 'dart:async';
// import 'dart:math'; // Matematik işlemleri (pow) için gerekli

// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:testrfidokuma/decode_page.dart'; // Eğer bu dosya yoksa veya adı farklıysa burayı düzelt
// import 'package:usb_serial/usb_serial.dart';
// import 'package:wakelock_plus/wakelock_plus.dart';

// // ==============================================================================
// // 1. UTILS (YARDIMCI ARAÇLAR)
// // ==============================================================================
// class WMBusUtils {
//   static String toHexString(List<int> bytes) {
//     return bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join(' ').toUpperCase();
//   }

//   static String decodeManufacturer(List<int> bytes) {
//     if (bytes.length < 2) return "UNK";
//     int m = (bytes[1] << 8) | bytes[0];
//     int char1 = (m >> 10) & 0x1F;
//     int char2 = (m >> 5) & 0x1F;
//     int char3 = m & 0x1F;
//     return String.fromCharCode(char1 + 64) + String.fromCharCode(char2 + 64) + String.fromCharCode(char3 + 64);
//   }

//   static int bcdToInt(List<int> bytes) {
//     // Little Endian BCD Okuma
//     // Örnek: [0x50, 0x10, 0x00, 0x00] -> 1050
//     int result = 0;
//     int multiplier = 1;
//     for (var b in bytes) {
//       int digit1 = b & 0x0F;
//       int digit2 = (b >> 4) & 0x0F;
//       result += (digit1 * multiplier) + (digit2 * multiplier * 10);
//       multiplier *= 100;
//     }
//     return result;
//   }
// }

// // ==============================================================================
// // 2. MODELLER
// // ==============================================================================
// class MeterReading {
//   final String serialNumber;
//   String manufacturer;
//   String deviceType;
//   Map<String, dynamic> data;
//   DateTime? timestamp;
//   bool isRead;
//   String rawHex;

//   MeterReading({
//     required this.serialNumber,
//     this.manufacturer = "",
//     this.deviceType = "",
//     Map<String, dynamic>? data, // Null gelebilir
//     this.timestamp,
//     this.isRead = false,
//     this.rawHex = "",
//   }) : data = data ?? {}; // Eğer veri yoksa yeni, boş ve DEĞİŞTİRİLEBİLİR bir map oluştur.

//   @override
//   String toString() {
//     return 'MeterReading(serialNumber: $serialNumber, manufacturer: $manufacturer, deviceType: $deviceType, data: $data, timestamp: $timestamp, isRead: $isRead, rawHex: $rawHex)';
//   }
// }

// class WMBusFrame {
//   List<int> rawBytes;
//   late int lengthField;
//   late String manufacturer;
//   late String address;
//   late int type;
//   List<int> payload = [];

//   WMBusFrame(this.rawBytes) {
//     _parseLinkLayer();
//   }

//   void _parseLinkLayer() {
//     if (rawBytes.length < 10) return;
//     // Header Analizi
//     lengthField = rawBytes[0];
//     manufacturer = WMBusUtils.decodeManufacturer(rawBytes.sublist(2, 4));
//     var addrBytes = rawBytes.sublist(4, 8).reversed.toList();
//     address = addrBytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
//     type = rawBytes[9]; // Device Type (Gaz, Su, Isı vb.)

//     if (rawBytes.length > 10) {
//       payload = rawBytes.sublist(10);
//     }
//   }
// }

// // ==============================================================================
// // 3. PARSER (DÜZELTİLMİŞ & GÜNCELLENMİŞ VERSİYON)
// // ==============================================================================
// class WMBusParser {
//   MeterReading parseFrameData(WMBusFrame frame, MeterReading existingRecord) {
//     Map<String, dynamic> parsedData = _parseDataRecords(frame.payload);

//     // Yeni okunan verileri mevcut kayda ekle
//     existingRecord.manufacturer = frame.manufacturer;
//     existingRecord.deviceType = _getDeviceTypeString(frame.type);

//     // Eski dataları koru, yenileri üstüne yaz
//     parsedData.forEach((key, value) {
//       existingRecord.data[key] = value;
//     });

//     existingRecord.timestamp = DateTime.now();
//     existingRecord.isRead = true;
//     existingRecord.rawHex = WMBusUtils.toHexString(frame.rawBytes);

//     return existingRecord;
//   }

//   Map<String, dynamic> _parseDataRecords(List<int> payload) {
//     Map<String, dynamic> results = {};
//     int index = 0;
//     int storageCounter = 0;

//     try {
//       while (index < payload.length) {
//         // --- DIF OKUMA ---
//         int dif = payload[index++];
//         if (dif == 0x2F) continue; // Idle Filler
//         if (dif == 0x0F || dif == 0x1F) break; // End of Record

//         int type = dif & 0x0F;
//         int storageBit = (dif >> 6) & 0x01;
//         bool isExtension = (dif & 0x80) != 0;

//         // DIF Extension varsa atla
//         while (isExtension && index < payload.length) {
//           int nextDif = payload[index++];
//           isExtension = (nextDif & 0x80) != 0;
//         }

//         // --- UZUNLUK BELİRLEME (HATA BURADAYDI, DÜZELTİLDİ) ---
//         int dataLen = 0;
//         switch (type) {
//           case 0x00:
//             dataLen = 0;
//             break; // No data
//           case 0x01:
//             dataLen = 1;
//             break; // 8-bit Int
//           case 0x02:
//             dataLen = 2;
//             break; // 16-bit Int
//           case 0x03:
//             dataLen = 3;
//             break; // 24-bit Int
//           case 0x04:
//             dataLen = 4;
//             break; // 32-bit Int
//           case 0x05:
//             dataLen = 4;
//             break; // 32-bit Real
//           case 0x06:
//             dataLen = 6;
//             break; // 48-bit Int
//           case 0x07:
//             dataLen = 8;
//             break; // 64-bit Int

//           // BCD Formatları
//           case 0x09:
//             dataLen = 4;
//             break; // Nadir
//           case 0x0A:
//             dataLen = 4;
//             break; // 4 byte BCD (8 hane)
//           case 0x0B:
//             dataLen = 6;
//             break; // 6 byte BCD (12 hane)
//           case 0x0C:
//             dataLen = 4;
//             break; // *** KRİTİK DÜZELTME: 6 DEĞİL 4 OLACAK ***
//           case 0x0E:
//             dataLen = 6;
//             break;

//           case 0x0D: // Variable length
//             if (index < payload.length) {
//               int lvar = payload[index++];
//               if (lvar < 0xC0)
//                 dataLen = lvar;
//               else
//                 return results; // Şifreli vs, çıkış yap
//             } else
//               return results;
//             break;
//           default:
//             return results; // Bilinmeyen tip, güvenli çıkış
//         }

//         // --- VIF OKUMA ---
//         if (index >= payload.length) break;
//         int vif = payload[index++];

//         bool vifExtension = (vif & 0x80) != 0;
//         while (vifExtension && index < payload.length) {
//           int nextVif = payload[index++];
//           vifExtension = (nextVif & 0x80) != 0;
//         }

//         // --- VERİ OKUMA ---
//         if (index + dataLen > payload.length) break;
//         List<int> valBytes = payload.sublist(index, index + dataLen);
//         index += dataLen;

//         // --- ETİKET OLUŞTURMA (Hafıza verisi mi?) ---
//         String labelPrefix = "";
//         if (storageBit == 1) {
//           // Basitçe hafıza sayacı, gerçekte DIF'ten storage nosu çekilebilir
//           labelPrefix = "Hafıza ";
//         }

//         // --- DEĞERİ ÇÖZÜMLE ---
//         _interpretValue(vif, valBytes, labelPrefix, results, type);
//       }
//     } catch (e) {
//       print("Parse Hatası: $e");
//     }
//     return results;
//   }

//   void _interpretValue(int vif, List<int> valBytes, String prefix, Map<String, dynamic> results, int dataType) {
//     int cleanVif = vif & 0x7F;

//     // --- ENERJİ (kWh/Wh) -> 0x00 .. 0x07 ---
//     // (10^(vif-3)) Wh
//     if ((cleanVif & 0x78) == 0x00) {
//       int exponent = (cleanVif & 0x07) - 3;
//       double val = _parseNumber(valBytes, dataType);
//       double energyWh = val * pow(10, exponent);
//       double energyKwh = energyWh / 1000.0;

//       String key = prefix.isEmpty ? "Enerji" : "${prefix}Enerji";
//       // Eğer aynı isimde key varsa çakışmayı önle
//       if (results.containsKey(key)) key = "$key (2)";

//       results[key] = "${energyKwh.toStringAsFixed(3)} kWh";
//     }
//     // --- HACİM (m3) -> 0x10 .. 0x17 ---
//     // (10^(vif-6)) m3
//     else if ((cleanVif & 0x78) == 0x10) {
//       int exponent = (cleanVif & 0x07) - 6;
//       double val = _parseNumber(valBytes, dataType);
//       double vol = val * pow(10, exponent);

//       String key = prefix.isEmpty ? "Hacim" : "${prefix}Hacim";
//       if (results.containsKey(key)) key = "$key (2)";

//       results[key] = "${vol.toStringAsFixed(3)} m³";
//     }
//     // --- TARİH (0x6C) ---
//     else if (cleanVif == 0x6C) {
//       String key = prefix.isEmpty ? "Tarih" : "${prefix}Tarih";
//       results[key] = _parseDate(valBytes);
//     }
//     // Diğerleri...
//   }

//   double _parseNumber(List<int> bytes, int type) {
//     // BCD Tipleri: 0x09, 0x0A, 0x0B, 0x0C, 0x0E
//     if (type == 0x09 || type == 0x0A || type == 0x0B || type == 0x0C || type == 0x0E) {
//       return WMBusUtils.bcdToInt(bytes).toDouble();
//     }
//     // Integer Tipleri: Little Endian
//     else {
//       int val = 0;
//       for (int i = 0; i < bytes.length; i++) {
//         val |= (bytes[i] << (i * 8));
//       }
//       return val.toDouble();
//     }
//   }

//   String _parseDate(List<int> bytes) {
//     if (bytes.length < 2) return "";
//     int val = (bytes[1] << 8) | bytes[0];
//     int day = val & 0x1F;
//     int month = (val >> 5) & 0x0F;
//     int year = (val >> 9) & 0x7F;
//     return "$day.$month.${2000 + year}";
//   }

//   String _getDeviceTypeString(int type) {
//     switch (type) {
//       case 0x03:
//         return "Gaz";
//       case 0x04:
//         return "Isı";
//       case 0x07:
//         return "Su";
//       default:
//         return "Tip($type)";
//     }
//   }
// }

// // ==============================================================================
// // 4. UI (ARAYÜZ)
// // ==============================================================================

// void main() {
//   runApp(const MaterialApp(debugShowCheckedModeBanner: false, home: WirelessMBusApp()));
// }

// class WirelessMBusApp extends StatefulWidget {
//   const WirelessMBusApp({super.key});
//   @override
//   State<WirelessMBusApp> createState() => _WirelessMBusAppState();
// }

// class _WirelessMBusAppState extends State<WirelessMBusApp> {
//   List<UsbDevice> _devices = [];
//   UsbDevice? _selectedDevice;
//   UsbPort? _port;
//   StreamSubscription<Uint8List>? _subscription;

//   final WMBusParser _parser = WMBusParser();
//   final List<int> _rxBuffer = [];
//   final List<String> _logs = [];
//   final ScrollController _logScrollController = ScrollController();

//   // Hedef Sayaç Listesi
//   final List<MeterReading> _targetList = [
//     MeterReading(serialNumber: "67352271"),
//     MeterReading(serialNumber: "66946295"),
//     MeterReading(serialNumber: "67659800"),
//   ];

//   final int _baudRate = 9600;
//   bool _isConnected = false;

//   @override
//   void initState() {
//     super.initState();
//     WakelockPlus.toggle(enable: true); // Ekran açık kalsın
//     UsbSerial.usbEventStream!.listen((event) => _getPorts());
//     _getPorts();
//   }

//   @override
//   void dispose() {
//     _disconnect();
//     super.dispose();
//   }

//   Future<void> _getPorts() async {
//     List<UsbDevice> devices = await UsbSerial.listDevices();
//     if (!mounted) return;
//     setState(() => _devices = devices);
//   }

//   Future<void> _connect() async {
//     if (_selectedDevice == null) return;
//     try {
//       _port = await _selectedDevice!.create();
//       bool openResult = await _port!.open();
//       if (!openResult) {
//         _addLog("HATA: Port açılamadı.");
//         return;
//       }

//       await _port!.setDTR(true);
//       await _port!.setRTS(true);
//       await _port!.setFlowControl(UsbPort.FLOW_CONTROL_OFF);
//       await _port!.setPortParameters(_baudRate, UsbPort.DATABITS_8, UsbPort.STOPBITS_1, UsbPort.PARITY_NONE);

//       _subscription = _port!.inputStream!.listen(
//         _handleIncomingData,
//         onError: (err) {
//           _addLog("Err: $err");
//         },
//       );

//       setState(() => _isConnected = true);
//       _addLog("BAĞLANDI: $_baudRate baud. Config Yükle!");
//     } catch (e) {
//       _addLog("Hata: $e");
//       _disconnect();
//     }
//   }

//   void _disconnect() {
//     _subscription?.cancel();
//     _port?.close();
//     _subscription = null;
//     _port = null;
//     if (mounted) {
//       setState(() {
//         _isConnected = false;
//         _rxBuffer.clear();
//       });
//       _addLog("Bağlantı kesildi.");
//     }
//   }

//   Future<void> _configureDevice() async {
//     if (!_isConnected || _port == null) return;
//     _addLog("Config Yükleniyor...");

//     Future<void> sendHex(String hex) async {
//       List<int> bytes = [];
//       hex.split(' ').forEach((s) {
//         if (s.isNotEmpty) bytes.add(int.parse(s, radix: 16));
//       });
//       _addLog("TX: $hex");
//       await _port!.write(Uint8List.fromList(bytes));
//       await Future.delayed(const Duration(milliseconds: 300));
//     }

//     // Cihaz başlatma komutları (Senin verdiğin sıraya göre)
//     await sendHex("FF 11 00 EE");
//     await sendHex("FF 05 00 FA");
//     await sendHex("FF 09 03 05 01 01 F0");
//     await sendHex("FF 09 03 45 01 01 B0");
//     await sendHex("FF 09 03 46 01 09 BB");
//     await sendHex("FF 05 00 FA");

//     _addLog("Config Bitti. Sayaçlar Bekleniyor...");
//   }

//   void _handleIncomingData(Uint8List data) {
//     // Gelen ham veriyi logla (Debugging için önemli)
//     String hexRaw = WMBusUtils.toHexString(data);
//     _addLog("RX: $hexRaw");

//     _rxBuffer.addAll(data);

//     // Buffer içinde en azından Header (Header + LEN) var mı?
//     while (_rxBuffer.length > 4) {
//       // 1. Header Kontrolü (FF 03)
//       if (!(_rxBuffer[0] == 0xFF && _rxBuffer[1] == 0x03)) {
//         // Çöp veriyi temizle, bir sonraki byte'tan devam et
//         _rxBuffer.removeAt(0);
//         continue;
//       }

//       // 2. Paket Uzunluğunu Hesapla
//       int lengthPayload = _rxBuffer[2];
//       int totalPacketSize = lengthPayload + 4; // FF 03 LEN [DATA...] Checksum

//       // 3. Yeterli veri geldi mi?
//       if (_rxBuffer.length < totalPacketSize) {
//         // Verinin geri kalanını bekle
//         break;
//       }

//       // 4. Paketi Kesip Al
//       List<int> fullPacket = _rxBuffer.sublist(0, totalPacketSize);
//       // Buffer'dan sil
//       _rxBuffer.removeRange(0, totalPacketSize);

//       // Veri kısmını (Payload) çıkar: FF 03 LEN [PAYLOAD] Checksum
//       // Senin loglarda Payload 2. indexte başlıyordu ama genelde FF 03 LEN DATA şeklindedir.
//       // Koddaki eski mantığını koruyorum:
//       List<int> validData = fullPacket.sublist(2, 2 + lengthPayload);

//       // Özel şifre çözme/kaydırma (eski kodundan)
//       if (validData.isNotEmpty) validData[0] = (validData[0] - 1) & 0xFF;

//       _processWMBusPacket(validData);
//     }
//   }

//   void _processWMBusPacket(List<int> bytes) {
//     try {
//       WMBusFrame frame = WMBusFrame(bytes);
//       String serial = frame.address;

//       int index = _targetList.indexWhere((m) => m.serialNumber == serial);

//       setState(() {
//         if (index != -1) {
//           // Listede var, güncelle
//           _targetList[index] = _parser.parseFrameData(frame, _targetList[index]);
//           _addLog("HEDEF GÜNCELLENDİ: $serial");
//         } else {
//           // Listede yok, yeni ekle (İsteğe bağlı)
//           MeterReading newMeter = MeterReading(serialNumber: serial);
//           _targetList.add(_parser.parseFrameData(frame, newMeter));
//           _addLog("YENİ SAYAÇ: $serial");
//         }
//       });
//     } catch (e) {
//       _addLog("Paket İşleme Hatası: $e");
//     }
//   }

//   void _addLog(String msg) {
//     if (!mounted) return;
//     setState(() => _logs.add("${DateTime.now().hour}:${DateTime.now().minute}:${DateTime.now().second} -> $msg"));

//     // Log ekranını aşağı kaydır
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       if (_logScrollController.hasClients) {
//         _logScrollController.jumpTo(_logScrollController.position.maxScrollExtent);
//       }
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     int okunanSayisi = _targetList.where((m) => m.isRead).length;
//     int toplamSayi = _targetList.length;

//     return Scaffold(
//       floatingActionButton: FloatingActionButton(
//         onPressed: () {
//           // DecodePage senin diğer sayfan, import'u ekledim
//           Navigator.push(
//             context,
//             MaterialPageRoute(
//               builder: (context) => const DecodePage(),
//             ),
//           );
//         },
//         backgroundColor: Colors.indigo,
//         child: const Icon(Icons.refresh),
//       ),
//       appBar: AppBar(
//         title: Text("Sayaç ($okunanSayisi/$toplamSayi)"),
//         backgroundColor: Colors.indigo,
//         actions: [IconButton(icon: const Icon(Icons.delete), onPressed: () => setState(() => _logs.clear()))],
//       ),
//       body: Column(
//         children: [
//           // Üst Kontrol Paneli
//           Container(
//             padding: const EdgeInsets.all(8),
//             color: Colors.grey[200],
//             child: Column(
//               children: [
//                 DropdownButton<UsbDevice>(
//                   isExpanded: true,
//                   value: _selectedDevice,
//                   hint: const Text("USB Cihazı Seç"),
//                   items: _devices.map((d) => DropdownMenuItem(value: d, child: Text(d.productName ?? "Bilinmeyen Cihaz"))).toList(),
//                   onChanged: _isConnected ? null : (v) => setState(() => _selectedDevice = v),
//                 ),
//                 const SizedBox(height: 5),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   children: [
//                     ElevatedButton(
//                       onPressed: _isConnected ? _disconnect : _connect,
//                       style: ElevatedButton.styleFrom(backgroundColor: _isConnected ? Colors.red : Colors.green),
//                       child: Text(_isConnected ? "KES" : "BAĞLAN"),
//                     ),
//                     ElevatedButton.icon(
//                       onPressed: _isConnected ? _configureDevice : null,
//                       icon: const Icon(Icons.settings),
//                       label: const Text("CONFIG"),
//                       style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ),

//           // Sayaç Listesi
//           Expanded(
//             child: ListView.builder(
//               itemCount: _targetList.length,
//               itemBuilder: (ctx, i) {
//                 final r = _targetList[i];
//                 Color cardColor = r.isRead ? Colors.green[50]! : Colors.white;
//                 IconData icon = r.isRead ? Icons.check_circle : Icons.hourglass_empty;
//                 Color iconColor = r.isRead ? Colors.green : Colors.grey;

//                 return Card(
//                   color: cardColor,
//                   margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//                   child: ListTile(
//                     leading: Icon(icon, color: iconColor, size: 30),
//                     title: Text(r.serialNumber, style: const TextStyle(fontWeight: FontWeight.bold)),
//                     subtitle: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         if (r.isRead) ...[
//                           Text("${r.manufacturer} - ${r.deviceType}", style: const TextStyle(fontSize: 12)),
//                           const Divider(height: 10),
//                           // Okunan Verileri Göster
//                           ...r.data.entries.map(
//                             (e) => Text(
//                               "${e.key}: ${e.value}",
//                               style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
//                             ),
//                           ),
//                           const SizedBox(height: 4),
//                           // Raw Data (Kopyalanabilir)
//                           InkWell(
//                             onTap: () => Clipboard.setData(ClipboardData(text: r.toString())),
//                             child: Container(
//                               padding: const EdgeInsets.all(4),
//                               decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(4)),
//                               child: Text(
//                                 "RAW: ${r.rawHex}",
//                                 style: const TextStyle(fontFamily: 'monospace', fontSize: 10, color: Colors.black54),
//                                 maxLines: 1,
//                                 overflow: TextOverflow.ellipsis,
//                               ),
//                             ),
//                           ),
//                         ] else ...[
//                           const Text("Bekleniyor...", style: TextStyle(color: Colors.redAccent)),
//                         ],
//                       ],
//                     ),
//                     trailing: r.isRead ? Text("${r.timestamp!.hour}:${r.timestamp!.minute}") : const SizedBox(),
//                   ),
//                 );
//               },
//             ),
//           ),

//           // Log Ekranı
//           Container(
//             height: 120,
//             color: Colors.black,
//             child: ListView.builder(
//               controller: _logScrollController,
//               itemCount: _logs.length,
//               itemBuilder: (ctx, i) => Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
//                 child: InkWell(
//                   onTap: () => Clipboard.setData(ClipboardData(text: _logs.toString())),
//                   child: Text(
//                     _logs[i],
//                     style: const TextStyle(color: Colors.greenAccent, fontSize: 10, fontFamily: 'monospace'),
//                   ),
//                 ),
//               ),
//             ),
//           ),
//           const SafeArea(child: SizedBox()),
//         ],
//       ),
//     );
//   }
// }
