// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:testrfidokuma/parse_new.dart';

// class DecodePage extends StatefulWidget {
//   const DecodePage({super.key});

//   @override
//   State<DecodePage> createState() => _DecodePageState();
// }

// class _DecodePageState extends State<DecodePage> {
//   final Rx<MeterReading> decodedData = MeterReading(
//     manufacturer: '',
//     serialNumber: '',
//     deviceType: '',
//     version: 1,
//     encryption: '',
//     frameType: '',
//     values: [],
//     parseTime: DateTime.now(),
//   ).obs;
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Decode Page'),
//       ),
//       body: Column(
//         children: [
//           ElevatedButton(
//             onPressed: () {
//               /* 
//               MeterReading(serialNumber: 67659800, manufacturer: QDS, deviceType: Tip(55), data: {Geçmiş-1 Enerji: 0.026 kWh, Geçmiş-2 Hacim: 435758448336307.250 m³}, timestamp: 2026-01-04 00:53:38.937809, isRead: true, rawHex: 41 44 93 44 00 98 65 67 46 37 72 00 98 65 67 93 44 46 04 F6 00 00 20 0C 06 50 10 00 00 4C 06 50 10 00 00 42 6C 3F 3C CC 08 06 50 10 00 00 C2 08 6C 3F 3C 02 FD 17 00 00 32 6C FF FF 04 6D 08 17 43 31)
//                */
//               String hex = "41 44 93 44 00 98 65 67 46 37 72 00 98 65 67 93 44 46 04 F6 00 00 20 0C 06 50 10 00 00 4C 06 50 10 00 00 42 6C 3F 3C CC 08 06 50 10 00 00 C2 08 6C 3F 3C 02 FD 17 00 00 32 6C FF FF 04 6D 08 17 43 31";
//               WMBusParser parser = WMBusParser();
//               debugPrint(parser.parseHexString(hex).toString());
//               decodedData.value = parser.parseHexString(hex);
//             },
//             child: const Text("Decode"),
//           ),

//           /// show like list view
//           // show decodedData values
//           Obx(() {
//             return Expanded(
//               child: ListView.builder(
//                 itemCount: decodedData.value.values.length,
//                 itemBuilder: (context, index) {
//                   final item = decodedData.value.values[index];
//                   return ListTile(
//                     title: Text('${item.description}: ${item.value} ${item.unit}'),
//                   );
//                 },
//               ),
//             );
//           }),
//         ],
//       ),
//     );
//   }
// }
