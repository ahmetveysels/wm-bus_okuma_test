// import 'dart:async';
// import 'dart:typed_data';

// import 'package:flutter/material.dart';
// import 'package:usb_serial/usb_serial.dart';
// import 'package:wakelock_plus/wakelock_plus.dart';

// // ==============================================================================
// // 1. UTILS (YARDIMCI ARAÇLAR)
// // ==============================================================================
// class WMBusUtils {
//   static String toHexString(List<int> bytes) {
//     return bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join(' ').toUpperCase();
//   }

//   static String decodeManufacturer(List<int> bytes) {
//     if (bytes.length < 2) return "UNK";
//     int m = (bytes[1] << 8) | bytes[0];
//     int char1 = (m >> 10) & 0x1F;
//     int char2 = (m >> 5) & 0x1F;
//     int char3 = m & 0x1F;
//     return String.fromCharCode(char1 + 64) + String.fromCharCode(char2 + 64) + String.fromCharCode(char3 + 64);
//   }

//   static int bcdToInt(List<int> bytes) {
//     int result = 0;
//     int multiplier = 1;
//     for (var b in bytes) {
//       int digit1 = b & 0x0F;
//       int digit2 = (b >> 4) & 0x0F;
//       result += (digit1 * multiplier) + (digit2 * multiplier * 10);
//       multiplier *= 100;
//     }
//     return result;
//   }
// }

// // ==============================================================================
// // 2. MODELLER
// // ==============================================================================
// class MeterReading {
//   final String serialNumber;
//   String manufacturer;
//   String deviceType;
//   Map<String, dynamic> data;
//   DateTime? timestamp;
//   bool isRead;
//   String rawHex; // YENİ: Raw Data Saklama Alanı

//   MeterReading({
//     required this.serialNumber,
//     this.manufacturer = "",
//     this.deviceType = "",
//     this.data = const {},
//     this.timestamp,
//     this.isRead = false,
//     this.rawHex = "", // Varsayılan boş
//   });
// }

// class WMBusFrame {
//   List<int> rawBytes;
//   late int lengthField;
//   late String manufacturer;
//   late String address;
//   late int type;
//   List<int> payload = [];

//   WMBusFrame(this.rawBytes) {
//     _parseLinkLayer();
//   }

//   void _parseLinkLayer() {
//     if (rawBytes.length < 10) return;
//     lengthField = rawBytes[0];
//     manufacturer = WMBusUtils.decodeManufacturer(rawBytes.sublist(2, 4));
//     var addrBytes = rawBytes.sublist(4, 8).reversed.toList();
//     address = addrBytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
//     type = rawBytes[9];

//     if (rawBytes.length > 10) {
//       payload = rawBytes.sublist(10);
//     }
//   }
// }

// // ==============================================================================
// // 3. PARSER
// // ==============================================================================
// class WMBusParser {
//   // Örnek Keyler
//   final Map<String, String> _keyStore = {
//     "67352271": "000102030405060708090A0B0C0D0E0F",
//     "66946295": "000102030405060708090A0B0C0D0E0F",
//     "67659800": "000102030405060708090A0B0C0D0E0F",
//   };

//   MeterReading parseFrameData(WMBusFrame frame, MeterReading existingRecord) {
//     Map<String, dynamic> parsedData = _parseDataRecords(frame.payload);

//     existingRecord.manufacturer = frame.manufacturer;
//     existingRecord.deviceType = _getDeviceTypeString(frame.type);
//     existingRecord.data = parsedData;
//     existingRecord.timestamp = DateTime.now();
//     existingRecord.isRead = true;

//     // YENİ: Raw Hex verisini kaydet
//     existingRecord.rawHex = WMBusUtils.toHexString(frame.rawBytes);

//     return existingRecord;
//   }

//   Map<String, dynamic> _parseDataRecords(List<int> payload) {
//     Map<String, dynamic> results = {};
//     int index = 0;

//     try {
//       while (index < payload.length) {
//         int dib = payload[index++];
//         if (dib == 0x2F) continue;
//         if (dib == 0x0F || dib == 0x1F) break;

//         int dataLen = 0;
//         int type = dib & 0x0F;

//         if (type == 0x01)
//           dataLen = 1;
//         else if (type == 0x02)
//           dataLen = 2;
//         else if (type == 0x04)
//           dataLen = 4;
//         else if (type == 0x06)
//           dataLen = 6;
//         else if (type == 0x0A)
//           dataLen = 4;
//         else if (type == 0x0C)
//           dataLen = 6;
//         else
//           break;

//         if (index >= payload.length) break;
//         int vib = payload[index++];

//         if (index + dataLen > payload.length) break;
//         List<int> valBytes = payload.sublist(index, index + dataLen);
//         index += dataLen;

//         _interpretValue(vib, valBytes, results);
//       }
//     } catch (e) {}
//     return results;
//   }

//   void _interpretValue(int vib, List<int> valBytes, Map<String, dynamic> results) {
//     int val = WMBusUtils.bcdToInt(valBytes);
//     if ((vib & 0x78) == 0x00)
//       results['Enerji'] = "$val Wh";
//     else if ((vib & 0x78) == 0x10)
//       results['Hacim'] = "$val m3";
//     else if (vib == 0x5B)
//       results['Gidiş Sıc.'] = "$val °C";
//     else if (vib == 0x5F)
//       results['Dönüş Sıc.'] = "$val °C";
//     else
//       results['Kod_${vib.toRadixString(16)}'] = val;
//   }

//   String _getDeviceTypeString(int type) {
//     switch (type) {
//       case 0x03:
//         return "Gaz";
//       case 0x04:
//         return "Isı";
//       case 0x07:
//         return "Su";
//       default:
//         return "Tip($type)";
//     }
//   }
// }

// // ==============================================================================
// // 4. UI
// // ==============================================================================

// void main() {
//   runApp(const MaterialApp(debugShowCheckedModeBanner: false, home: WirelessMBusApp()));
// }

// class WirelessMBusApp extends StatefulWidget {
//   const WirelessMBusApp({super.key});
//   @override
//   State<WirelessMBusApp> createState() => _WirelessMBusAppState();
// }

// class _WirelessMBusAppState extends State<WirelessMBusApp> {
//   List<UsbDevice> _devices = [];
//   UsbDevice? _selectedDevice;
//   UsbPort? _port;
//   StreamSubscription<Uint8List>? _subscription;

//   final WMBusParser _parser = WMBusParser();
//   final List<int> _rxBuffer = [];
//   final List<String> _logs = [];
//   final ScrollController _logScrollController = ScrollController();

//   // HEDEF LİSTE
//   final List<MeterReading> _targetList = [
//     MeterReading(serialNumber: "67352271"),
//     MeterReading(serialNumber: "66946295"),
//     MeterReading(serialNumber: "67659800"),
//   ];

//   final int _baudRate = 9600;
//   bool _isConnected = false;

//   @override
//   void initState() {
//     super.initState();
//     WakelockPlus.toggle(enable: true);
//     UsbSerial.usbEventStream!.listen((event) => _getPorts());
//     _getPorts();
//   }

//   @override
//   void dispose() {
//     _disconnect();
//     super.dispose();
//   }

//   Future<void> _getPorts() async {
//     List<UsbDevice> devices = await UsbSerial.listDevices();
//     if (!mounted) return;
//     setState(() => _devices = devices);
//   }

//   Future<void> _connect() async {
//     if (_selectedDevice == null) return;
//     try {
//       _port = await _selectedDevice!.create();
//       bool openResult = await _port!.open();
//       if (!openResult) {
//         _addLog("HATA: Port açılamadı.");
//         return;
//       }

//       await _port!.setDTR(true);
//       await _port!.setRTS(true);
//       await _port!.setFlowControl(UsbPort.FLOW_CONTROL_OFF);
//       await _port!.setPortParameters(_baudRate, UsbPort.DATABITS_8, UsbPort.STOPBITS_1, UsbPort.PARITY_NONE);

//       _subscription = _port!.inputStream!.listen(
//         _handleIncomingData,
//         onError: (err) {
//           _addLog("Err: $err");
//         },
//       );

//       setState(() => _isConnected = true);
//       _addLog("BAĞLANDI: $_baudRate baud. Config Yükle!");
//     } catch (e) {
//       _addLog("Hata: $e");
//       _disconnect();
//     }
//   }

//   void _disconnect() {
//     _subscription?.cancel();
//     _port?.close();
//     _subscription = null;
//     _port = null;
//     if (mounted) {
//       setState(() {
//         _isConnected = false;
//         _rxBuffer.clear();
//       });
//       _addLog("Bağlantı kesildi.");
//     }
//   }

//   Future<void> _configureDevice() async {
//     if (!_isConnected || _port == null) return;
//     _addLog("Config Yükleniyor...");

//     Future<void> sendHex(String hex) async {
//       List<int> bytes = [];
//       hex.split(' ').forEach((s) {
//         if (s.isNotEmpty) bytes.add(int.parse(s, radix: 16));
//       });

//       // TX LOG (GÖNDERİLEN)
//       _addLog("TX: $hex");

//       await _port!.write(Uint8List.fromList(bytes));
//       await Future.delayed(const Duration(milliseconds: 500));
//     }

//     await sendHex("FF 11 00 EE");
//     await sendHex("FF 05 00 FA");
//     await sendHex("FF 09 03 05 01 01 F0");
//     await sendHex("FF 09 03 45 01 01 B0");
//     await sendHex("FF 09 03 46 01 09 BB");
//     await sendHex("FF 05 00 FA");

//     _addLog("Config Bitti. Sayaçlar Bekleniyor...");
//   }

//   void _handleIncomingData(Uint8List data) {
//     // RX LOG (GELEN - HER ZAMAN)
//     String hexRaw = WMBusUtils.toHexString(data);
//     _addLog("RX: $hexRaw");

//     _rxBuffer.addAll(data);
//     while (_rxBuffer.length > 5) {
//       if (!(_rxBuffer[0] == 0xFF && _rxBuffer[1] == 0x03)) {
//         _rxBuffer.removeAt(0);
//         continue;
//       }
//       if (_rxBuffer.length > 3 && _rxBuffer[3] != 0x44) {
//         _rxBuffer.removeAt(0);
//         continue;
//       }
//       int lengthPayload = _rxBuffer[2];
//       int totalPacketSize = lengthPayload + 4;

//       if (_rxBuffer.length < totalPacketSize) break;

//       List<int> okunan = _rxBuffer.sublist(2, 2 + lengthPayload);
//       _rxBuffer.removeRange(0, totalPacketSize);

//       if (okunan.isNotEmpty) okunan[0] = (okunan[0] - 1) & 0xFF;

//       _processWMBusPacket(okunan);
//     }
//   }

//   void _processWMBusPacket(List<int> bytes) {
//     try {
//       WMBusFrame frame = WMBusFrame(bytes);
//       String serial = frame.address;

//       int index = _targetList.indexWhere((m) => m.serialNumber == serial);

//       setState(() {
//         if (index != -1) {
//           _targetList[index] = _parser.parseFrameData(frame, _targetList[index]);
//           _addLog("HEDEF BULUNDU: $serial");
//         } else {
//           MeterReading newMeter = MeterReading(serialNumber: serial);
//           _targetList.add(_parser.parseFrameData(frame, newMeter));
//           _addLog("YENİ SAYAÇ: $serial");
//         }
//       });
//     } catch (e) {
//       // _addLog("Parse Err: $e");
//     }
//   }

//   void _addLog(String msg) {
//     if (!mounted) return;
//     setState(() => _logs.add("${DateTime.now().hour}:${DateTime.now().minute}:${DateTime.now().second} -> $msg"));
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       if (_logScrollController.hasClients) _logScrollController.jumpTo(_logScrollController.position.maxScrollExtent);
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     int okunanSayisi = _targetList.where((m) => m.isRead).length;
//     int toplamSayi = _targetList.length;

//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Sayaç ($okunanSayisi/$toplamSayi)"),
//         backgroundColor: Colors.indigo,
//         actions: [IconButton(icon: const Icon(Icons.delete), onPressed: () => setState(() => _logs.clear()))],
//       ),
//       body: Column(
//         children: [
//           // Kontrol
//           Container(
//             padding: const EdgeInsets.all(8),
//             color: Colors.grey[200],
//             child: Column(
//               children: [
//                 DropdownButton<UsbDevice>(
//                   isExpanded: true,
//                   value: _selectedDevice,
//                   hint: const Text("USB Cihazı"),
//                   items: _devices.map((d) => DropdownMenuItem(value: d, child: Text(d.productName ?? "?"))).toList(),
//                   onChanged: _isConnected ? null : (v) => setState(() => _selectedDevice = v),
//                 ),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   children: [
//                     ElevatedButton(
//                       onPressed: _isConnected ? _disconnect : _connect,
//                       style: ElevatedButton.styleFrom(backgroundColor: _isConnected ? Colors.red : Colors.green),
//                       child: Text(_isConnected ? "KES" : "BAĞLAN"),
//                     ),
//                     ElevatedButton.icon(
//                       onPressed: _isConnected ? _configureDevice : null,
//                       icon: const Icon(Icons.settings),
//                       label: const Text("CONFIG YÜKLE"),
//                       style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ),

//           // Liste
//           Expanded(
//             child: ListView.builder(
//               itemCount: _targetList.length,
//               itemBuilder: (ctx, i) {
//                 final r = _targetList[i];
//                 Color cardColor = r.isRead ? Colors.green[50]! : Colors.white;
//                 IconData icon = r.isRead ? Icons.check_circle : Icons.hourglass_empty;
//                 Color iconColor = r.isRead ? Colors.green : Colors.grey;

//                 return Card(
//                   color: cardColor,
//                   margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//                   child: ListTile(
//                     leading: Icon(icon, color: iconColor, size: 30),
//                     title: Text(r.serialNumber, style: const TextStyle(fontWeight: FontWeight.bold)),
//                     subtitle: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         if (r.isRead) ...[
//                           Text("${r.manufacturer} - ${r.deviceType}", style: const TextStyle(fontSize: 12)),
//                           const SizedBox(height: 4),
//                           // PARSE EDİLMİŞ DATA
//                           Text(
//                             r.data.toString(),
//                             style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
//                           ),
//                           const SizedBox(height: 4),
//                           // --- YENİ EKLENEN RAW HEX BÖLÜMÜ ---
//                           Container(
//                             padding: const EdgeInsets.all(4),
//                             decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(4)),
//                             child: SelectableText(
//                               "RAW: ${r.rawHex}",
//                               style: const TextStyle(fontFamily: 'monospace', fontSize: 10, color: Colors.black54),
//                             ),
//                           ),
//                         ] else ...[
//                           const Text("Bekleniyor...", style: TextStyle(color: Colors.redAccent)),
//                         ],
//                       ],
//                     ),
//                     trailing: r.isRead ? Text("${r.timestamp!.hour}:${r.timestamp!.minute}") : const SizedBox(),
//                   ),
//                 );
//               },
//             ),
//           ),

//           // Log
//           Container(
//             height: 120,
//             color: Colors.black,
//             child: ListView.builder(
//               controller: _logScrollController,
//               itemCount: _logs.length,
//               itemBuilder: (ctx, i) => Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
//                 child: Text(
//                   _logs[i],
//                   style: const TextStyle(color: Colors.greenAccent, fontSize: 10, fontFamily: 'monospace'),
//                 ),
//               ),
//             ),
//           ),
//           const SafeArea(child: SizedBox()),
//         ],
//       ),
//     );
//   }
// }
