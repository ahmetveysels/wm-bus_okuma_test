import 'dart:typed_data';

import 'package:convert/convert.dart'; // pubspec.yaml: convert: ^3.1.1
import 'package:encrypt/encrypt.dart' as enc; // pubspec.yaml: encrypt: ^5.0.3

// ==============================================================================
// 1. DATA MODELS
// ==============================================================================
class ReadingValue {
  final String type;
  final String description;
  final dynamic value;
  final String unit;

  ReadingValue({
    required this.type,
    required this.description,
    required this.value,
    required this.unit,
  });

  @override
  String toString() => '$description: $value $unit';
}

class MeterReading {
  final String manufacturer;
  final String serialNumber;
  final String deviceType;
  final int version;
  final String encryption;
  final String frameType;
  final DateTime parseTime;
  final List<ReadingValue> values;
  final String? error;

  MeterReading({
    required this.manufacturer,
    required this.serialNumber,
    required this.deviceType,
    required this.version,
    required this.encryption,
    required this.frameType,
    required this.values,
    required this.parseTime,
    this.error,
  });

  @override
  String toString() {
    StringBuffer sb = StringBuffer();
    sb.writeln("=== SAYAÇ OKUMA SONUCU ===");
    sb.writeln("Marka       : $manufacturer ($frameType)");
    sb.writeln("Seri No     : $serialNumber");
    sb.writeln("Tip         : $deviceType (v$version)");
    sb.writeln("Durum       : $encryption");
    sb.writeln("--- DEĞERLER ---");
    if (values.isEmpty) {
      sb.writeln("  (Değer yok veya ayrıştırılamadı)");
    } else {
      for (var v in values) {
        sb.writeln("  * ${v.description.padRight(22)} : ${v.value} ${v.unit}");
      }
    }
    if (error != null) sb.writeln("!!! HATA: $error !!!");
    sb.writeln("==========================");
    return sb.toString();
  }
}

// ==============================================================================
// 2. UTILS & DECRYPTER
// ==============================================================================
class WMBusUtils {
  static Uint8List hexToBytes(String hexString) {
    hexString = hexString.replaceAll(" ", "").replaceAll("-", "").trim();
    if (hexString.length % 2 != 0) hexString = "0$hexString";
    return Uint8List.fromList(hex.decode(hexString));
  }

  static String decodeManufacturer(List<int> bytes) {
    if (bytes.length < 2) return "UNK";
    int m = (bytes[1] << 8) | bytes[0];
    int char1 = ((m >> 10) & 0x1F) + 64;
    int char2 = ((m >> 5) & 0x1F) + 64;
    int char3 = ((m) & 0x1F) + 64;
    return String.fromCharCode(char1) + String.fromCharCode(char2) + String.fromCharCode(char3);
  }

  static double decodeBCD(List<int> data) {
    double val = 0;
    bool errorFlag = false;
    for (int i = data.length - 1; i >= 0; i--) {
      int byte = data[i];
      if (((byte & 0xF0) > 0x90) || ((byte & 0x0F) > 0x09)) errorFlag = true;
      val = (val * 100) + ((byte >> 4) * 10) + (byte & 0x0F);
    }
    if (errorFlag || (data.isNotEmpty && data.last == 0x80)) return -1.0;
    return val;
  }

  static String getMediumString(int m) {
    switch (m) {
      case 0x03:
        return "Gaz";
      case 0x04:
        return "Isı";
      case 0x06:
        return "Sıcak Su";
      case 0x07:
        return "Su";
      case 0x16:
        return "Soğuk Su";
      case 0x37:
        return "Radio Converter (QDS)";
      case 0x44:
        return "Oda Sensörü / HCA (TCH)";
      default:
        return "Tip(0x${m.toRadixString(16)})";
    }
  }
}

class WMBusDecrypter {
  static Uint8List? decryptMode5(Uint8List payload, Uint8List key, Uint8List iv) {
    try {
      final keyParam = enc.Key(key);
      final ivParam = enc.IV(iv);
      final encrypter = enc.Encrypter(enc.AES(keyParam, mode: enc.AESMode.cbc, padding: null));

      List<int> paddedPayload = List.from(payload);
      while (paddedPayload.length % 16 != 0) paddedPayload.add(0x00);

      final decrypted = encrypter.decryptBytes(enc.Encrypted(Uint8List.fromList(paddedPayload)), iv: ivParam);
      return Uint8List.fromList(decrypted);
    } catch (e) {
      return null;
    }
  }

  static Uint8List generateIV(List<int> man, List<int> id, int ver, int med, int acc) {
    List<int> iv = [];
    iv.addAll(man);
    iv.addAll(id);
    iv.add(ver);
    iv.add(med);
    for (int i = 0; i < 8; i++) iv.add(acc);
    return Uint8List.fromList(iv);
  }
}

// ==============================================================================
// 3. MASTER PARSER (TÜM MARKALAR VE CSV UYUMLU)
// ==============================================================================
class WMBusParser {
  final List<String> _keys = [
    "00000000000000000000000000000000",
    "0102030405060708090A0B0C0D0E0F10",
    "F9213142F537196E5A9C061CEA2E6A56",
    "51728910E66D83F851728910E66D83F8",
    "39BC8A10E66D83F839BC8A10E66D83F8",
  ];

  MeterReading parseHexString(String hexString) {
    try {
      return _parseFrame(WMBusUtils.hexToBytes(hexString));
    } catch (e) {
      return _createErrorModel("Parse Hatası: $e");
    }
  }

  MeterReading _parseFrame(List<int> rawFrame) {
    if (rawFrame.length < 15) return _createErrorModel("Veri Çok Kısa");

    int offset = 2; // L ve C field geçildi varsayımı

    // 1. Header
    List<int> manBytes = rawFrame.sublist(offset, offset + 2);
    String manufacturer = WMBusUtils.decodeManufacturer(manBytes);
    offset += 2;

    List<int> idBytes = rawFrame.sublist(offset, offset + 4);
    String serialNumber = idBytes.reversed.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
    offset += 4;

    int version = rawFrame[offset++];
    int medium = rawFrame[offset++];

    // 2. CI Field Tespiti
    int ciField = rawFrame[offset];
    String detectedFrameType = "Standart OMS";

    // Elster Kayması Kontrolü
    if (![0x7A, 0x72, 0x78, 0xA0, 0xA1, 0xA2].contains(ciField)) {
      if (rawFrame.length > offset + 2 && [0x7A, 0x72, 0x78, 0xA0].contains(rawFrame[offset + 2])) {
        offset += 2;
        ciField = rawFrame[offset];
        detectedFrameType = "Elster/Shifted";
      }
    }
    offset++;

    // 3. Header Analizi
    int accessNo = 0;
    int encryptionMode = 0;

    if (ciField == 0x72) {
      // Long Header
      offset += 8;
      accessNo = rawFrame[offset++];
      offset++; // Status
      int config1 = rawFrame[offset++];
      offset++;
      encryptionMode = config1 & 0x0F;
    } else if (ciField == 0x7A) {
      // Short Header
      accessNo = rawFrame[offset++];
      offset++; // Status
      int config1 = rawFrame[offset++];
      int config2 = rawFrame[offset++];
      encryptionMode = config1 & 0x0F;
      if (encryptionMode == 0 && (config2 & 0x0F) == 5) encryptionMode = 5;
    } else if (ciField == 0x78) {
      // Qundis No Header
      detectedFrameType = "Qundis Walk-By";
      encryptionMode = 0;
    } else if (ciField >= 0xA0 && ciField <= 0xA8) {
      // Techem Compact
      detectedFrameType = "Techem Compact (${ciField.toRadixString(16).toUpperCase()})";
      offset++; // Access
      offset++; // Status
      int config1 = rawFrame[offset++];
      offset++; // Config2
      encryptionMode = config1 & 0x0F;
    }

    // 4. Payload & Decryption
    List<int> payload = rawFrame.sublist(offset);
    List<int> finalPayload = [];
    bool decryptionSuccess = false;

    if (encryptionMode == 5 || (encryptionMode == 0 && ciField != 0x78 && payload.length > 8 && ciField < 0xA0)) {
      Uint8List iv = WMBusDecrypter.generateIV(manBytes, idBytes, version, medium, accessNo);
      for (String keyHex in _keys) {
        Uint8List key = WMBusUtils.hexToBytes(keyHex);
        Uint8List? res = WMBusDecrypter.decryptMode5(Uint8List.fromList(payload), key, iv);
        if (res != null) {
          if ((res.length > 2 && res[0] == 0x2F && res[1] == 0x2F) || (res.isNotEmpty && res.last == 0x2F) || (res.isNotEmpty && (res[0] == 0x02 || res[0] == 0x04 || res[0] == 0x0C))) {
            finalPayload = res;
            decryptionSuccess = true;
            encryptionMode = 5;
            break;
          }
        }
      }
      if (!decryptionSuccess) finalPayload = payload;
    } else {
      finalPayload = payload;
      decryptionSuccess = true;
    }

    // 5. Parse Data
    List<ReadingValue> readings = _parseDataRecords(finalPayload);

    // Techem Özel Durum (Boş liste dönerse)
    if (readings.isEmpty && ciField >= 0xA0) {
      readings.add(ReadingValue(type: "Info", description: "Techem Durumu", value: "Beklemede/Hata", unit: ""));
    }

    return MeterReading(
      manufacturer: manufacturer,
      serialNumber: serialNumber,
      deviceType: WMBusUtils.getMediumString(medium),
      version: version,
      encryption: decryptionSuccess ? (encryptionMode == 0 ? "Şifresiz" : "AES Çözüldü") : "Bilinmiyor/Şifreli",
      frameType: detectedFrameType,
      values: readings,
      parseTime: DateTime.now(),
    );
  }

  List<ReadingValue> _parseDataRecords(List<int> data) {
    List<ReadingValue> results = [];
    int i = 0;
    while (i < data.length && data[i] == 0x2F) i++; // Skip Padding

    try {
      while (i < data.length) {
        int dif = data[i++];
        if (dif == 0x0F || dif == 0x1F) break;

        int dataLen = 0;
        int type = dif & 0x0F;
        String typeStr = "";

        if ((dif & 0x80) != 0) {
          // Extension
          if (i < data.length) {
            int dif2 = data[i++];
            type = dif2 & 0x0F;
          }
        }

        switch (type) {
          case 0x01:
            dataLen = 1;
            typeStr = "Int8";
            break;
          case 0x02:
            dataLen = 2;
            typeStr = "Int16";
            break;
          case 0x03:
            dataLen = 3;
            typeStr = "Int24";
            break;
          case 0x04:
            dataLen = 4;
            typeStr = "Int32";
            break;
          case 0x06:
            dataLen = 6;
            typeStr = "Int48";
            break;
          case 0x07:
            dataLen = 8;
            typeStr = "Int64";
            break;
          case 0x0C:
            dataLen = 4;
            typeStr = "BCD8";
            break;
          case 0x0D: // Var Length
            if (i < data.length) {
              dataLen = data[i++];
              if (dataLen >= 0x80) dataLen &= 0x7F;
            }
            typeStr = "String";
            break;
          default:
            dataLen = 0;
            break;
        }

        if (i >= data.length) break;
        int vif = data[i++];
        if ((vif & 0x80) != 0) {
          // VIFE
          while (i < data.length && (data[i] & 0x80) != 0) i++;
          i++;
        }

        if (i + dataLen > data.length) break;
        List<int> valBytes = data.sublist(i, i + dataLen);
        i += dataLen;

        dynamic finalVal = 0;
        String desc = "Data";
        String unit = "";

        if (typeStr == "String") {
          desc = "Ham Veri";
          finalVal = "[Binary]";
        } else {
          double numVal = 0;
          if (typeStr == "BCD8")
            numVal = WMBusUtils.decodeBCD(valBytes);
          else {
            int temp = 0;
            for (int k = 0; k < valBytes.length; k++) temp |= (valBytes[k] << (k * 8));
            numVal = temp.toDouble();
          }

          if (numVal == -1.0)
            finalVal = "Hata/Boş";
          else {
            if ((vif & 0x78) == 0x00) {
              desc = "Enerji";
              unit = "Wh";
              finalVal = numVal;
            } else if (vif == 0x06) {
              desc = "Enerji";
              unit = "kWh";
              finalVal = numVal;
            } else if ((vif & 0x78) == 0x10) {
              desc = "Hacim";
              unit = "m³";
              if (vif == 0x13)
                finalVal = numVal * 0.001;
              else if (vif == 0x14)
                finalVal = numVal * 0.01;
              else
                finalVal = numVal;
            } else if (vif == 0x20) {
              desc = "ON Süresi";
              unit = "sn";
              finalVal = numVal;
            } else {
              finalVal = numVal;
            }
          }
        }
        results.add(ReadingValue(type: "Data", description: desc, value: finalVal, unit: unit));
      }
    } catch (e) {}
    return results;
  }

  MeterReading _createErrorModel(String msg) {
    return MeterReading(manufacturer: "ERR", serialNumber: "0", deviceType: "Error", version: 0, encryption: "Error", frameType: "Error", values: [], parseTime: DateTime.now(), error: msg);
  }
}

// 4. TEST
void main() {
  String hex = "58 44 93 44 00 98 65 67 46 37 78 07 79 00 98 65 67 93 44 46 04 0D FF 5F 35 00 82 EB 00 00 61 01 07 C0 06 FF FF 50 10 00 00 3F 3C 50 10 00 00 3F 3C 50 10 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 2F 02 FD 17 00 00 04 6D 2E 0D 42 31";
  WMBusParser parser = WMBusParser();
  print(parser.parseHexString(hex));
}
