// import 'dart:async';
// import 'dart:typed_data';

// import 'package:flutter/material.dart';
// import 'package:usb_serial/usb_serial.dart';
// import 'package:wakelock_plus/wakelock_plus.dart';

// void main() {
//   runApp(
//     const MaterialApp(
//       debugShowCheckedModeBanner: false,
//       home: MbusProPage(),
//     ),
//   );
// }

// // --------------------------------------------------------------------------
// // 1. DATA MODELİ
// // --------------------------------------------------------------------------
// class MeterJob {
//   String serialNo;
//   String location; // Blok/Daire
//   bool isRead;
//   double value;
//   DateTime? readTime;

//   MeterJob({required this.serialNo, required this.location, this.isRead = false, this.value = 0.0});
// }

// class MbusProPage extends StatefulWidget {
//   const MbusProPage({super.key});

//   @override
//   State<MbusProPage> createState() => _MbusProPageState();
// }

// class _MbusProPageState extends State<MbusProPage> {
//   // --- PROJE LİSTESİ (BURAYA 300 SAYAÇ EKLEYEBİLİRSİN) ---
//   final List<MeterJob> _allJobs = [
//     MeterJob(serialNo: "67352271", location: "A Blok D:1"),
//     MeterJob(serialNo: "66946295", location: "A Blok D:2"),
//     MeterJob(serialNo: "67659800", location: "A Blok D:3"),
//     MeterJob(serialNo: "11111111", location: "A Blok D:4"),
//     MeterJob(serialNo: "22222222", location: "B Blok D:1"),
//     MeterJob(serialNo: "33333333", location: "B Blok D:2"),
//     MeterJob(serialNo: "44444444", location: "C Blok D:5"),
//     MeterJob(serialNo: "55555555", location: "Dükkan 1"),
//     MeterJob(serialNo: "66666666", location: "Dükkan 2"),
//     MeterJob(serialNo: "77777777", location: "Yönetim"),
//   ];

//   // Filtrelenmiş Liste (Arama için)
//   List<MeterJob> _filteredJobs = [];
//   String _searchText = "";
//   List<UsbDevice> _devices = [];
//   UsbDevice? _selectedDevice;
//   UsbPort? _port;
//   StreamSubscription? _subscription;

//   // Loglar
//   final ScrollController _logScroll = ScrollController();
//   final List<String> _logs = [];
//   bool _showLogs = true; // Logları gizleyip açmak için

//   bool _isConnected = false;
//   bool _isConfiguring = false;

//   @override
//   void initState() {
//     super.initState();
//     _filteredJobs = _allJobs; // Başlangıçta hepsi görünsün
//     _initPorts();
//     WakelockPlus.toggle(enable: true);
//     UsbSerial.usbEventStream?.listen((event) => _initPorts());
//   }

//   void _initPorts() async {
//     List<UsbDevice> devices = await UsbSerial.listDevices();
//     setState(() {
//       _devices = devices;
//       if (_devices.isNotEmpty && _selectedDevice == null) {
//         _selectedDevice = _devices.first;
//       }
//     });
//   }

//   // --- ARAMA FONKSİYONU ---
//   void _runFilter(String enteredKeyword) {
//     List<MeterJob> results = [];
//     if (enteredKeyword.isEmpty) {
//       results = _allJobs;
//     } else {
//       results = _allJobs.where((job) => job.serialNo.contains(enteredKeyword) || job.location.toLowerCase().contains(enteredKeyword.toLowerCase())).toList();
//     }
//     setState(() {
//       _filteredJobs = results;
//       _searchText = enteredKeyword;
//     });
//   }

//   // --- BAĞLANTI (SENKRON AYARLI) ---
//   void _connect() async {
//     if (_selectedDevice == null) return;

//     try {
//       _port = await _selectedDevice!.create();
//       if (!await _port!.open()) return;

//       await _port!.setDTR(true);
//       await _port!.setRTS(true);
//       await _port!.setPortParameters(9600, UsbPort.DATABITS_8, UsbPort.STOPBITS_1, UsbPort.PARITY_NONE);

//       _subscription = _port!.inputStream!.listen(_onDataReceived);

//       setState(() {
//         _isConnected = true;
//         _isConfiguring = true;
//       });

//       _addLog("🚀 BAĞLANDI. KURULUM BAŞLIYOR (Lütfen Bekleyin)...");

//       // --- İŞTE O SİHİRLİ SIRALAMA ---
//       await _sendHex("FF 11 00 EE"); // Factory
//       await Future.delayed(const Duration(seconds: 4)); // Uzun bekle

//       await _sendHex("FF 05 00 FA"); // Reset
//       await Future.delayed(const Duration(seconds: 2));

//       await _sendHex("FF 09 03 02 02 F7"); // T1 Modu
//       await Future.delayed(const Duration(seconds: 2));

//       await _sendHex("FF 09 03 05 01 01 F0"); // UART Aç

//       setState(() => _isConfiguring = false);
//       _addLog("✅ SİSTEM HAZIR! SAYAÇLAR BEKLENİYOR...");
//     } catch (e) {
//       _disconnect();
//     }
//   }

//   void _disconnect() {
//     _subscription?.cancel();
//     _port?.close();
//     setState(() {
//       _isConnected = false;
//       _isConfiguring = false;
//     });
//   }

//   // --- VERİ GELDİĞİNDE ---
//   void _onDataReceived(Uint8List data) {
//     String rawHex = data.map((e) => e.toRadixString(16).padLeft(2, '0').toUpperCase()).join(' ');

//     // Konfigürasyon mesajlarını gizle (Sadece RX 77 gibi kritik şeyleri göster)
//     if (rawHex.startsWith("FF 8") || rawHex.startsWith("FF 9")) return;

//     _addLog("RX: $rawHex");

//     // PARSER
//     ParsedData result = RFParser.parse(data);

//     // LİSTEDE ARA
//     bool found = false;
//     for (var job in _allJobs) {
//       // Daha önce okunmadıysa ve eşleşiyorsa
//       if (!job.isRead) {
//         if ((result.serialNo != "-" && result.serialNo.contains(job.serialNo)) || rawHex.replaceAll(" ", "").contains(job.serialNo)) {
//           setState(() {
//             job.isRead = true;
//             job.value = result.reading;
//             job.readTime = DateTime.now();
//           });
//           _addLog("🏆 OKUNDU: ${job.location} (SN:${job.serialNo})");

//           // Okunan cihazı göstermek için filtreyi temizleyebilir veya snackbar atabiliriz
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(content: Text("OKUNDU: ${job.location}"), backgroundColor: Colors.green, duration: const Duration(seconds: 2)),
//           );
//           found = true;
//         }
//       }
//     }
//   }

//   Future<void> _sendHex(String hex) async {
//     if (_port == null) return;
//     List<int> bytes = [];
//     hex = hex.replaceAll(" ", "");
//     for (int i = 0; i < hex.length; i += 2) {
//       bytes.add(int.parse(hex.substring(i, i + 2), radix: 16));
//     }
//     await _port!.write(Uint8List.fromList(bytes));
//     _addLog("TX: $hex");
//   }

//   void _addLog(String msg) {
//     if (_logs.length > 100) _logs.removeAt(0);
//     setState(() => _logs.add(msg));
//     if (_showLogs) {
//       WidgetsBinding.instance.addPostFrameCallback((_) {
//         if (_logScroll.hasClients) _logScroll.jumpTo(_logScroll.position.maxScrollExtent);
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     int readCount = _allJobs.where((j) => j.isRead).length;
//     double progress = _allJobs.isEmpty ? 0 : readCount / _allJobs.length;

//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Proje Yöneticisi"),
//         backgroundColor: Colors.indigo[900],
//         foregroundColor: Colors.white,
//         bottom: PreferredSize(
//           preferredSize: const Size.fromHeight(60),
//           child: Container(
//             color: Colors.white,
//             padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
//             child: Column(
//               children: [
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     Text("İlerleme: %${(progress * 100).toInt()}", style: const TextStyle(fontWeight: FontWeight.bold)),
//                     Text("$readCount / ${_allJobs.length} Sayaç"),
//                   ],
//                 ),
//                 LinearProgressIndicator(value: progress, minHeight: 8, backgroundColor: Colors.grey[300], color: Colors.green),
//               ],
//             ),
//           ),
//         ),
//       ),
//       body: Column(
//         children: [
//           // 1. ÜST PANEL (PORT & ARAMA)
//           Container(
//             padding: const EdgeInsets.all(8),
//             color: Colors.grey[100],
//             child: Column(
//               children: [
//                 Row(
//                   children: [
//                     Expanded(
//                       flex: 3,
//                       child: DropdownButtonFormField<UsbDevice>(
//                         initialValue: _selectedDevice,
//                         isExpanded: true,
//                         items: _devices.map((e) => DropdownMenuItem(value: e, child: Text(e.productName ?? "USB Serial"))).toList(),
//                         onChanged: _isConnected ? null : (v) => setState(() => _selectedDevice = v),
//                         decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 10), border: OutlineInputBorder(), labelText: "Port"),
//                       ),
//                     ),
//                     const SizedBox(width: 5),
//                     Expanded(
//                       flex: 2,
//                       child: ElevatedButton(
//                         onPressed: _devices.isEmpty || _isConfiguring ? null : (_isConnected ? _disconnect : _connect),
//                         style: ElevatedButton.styleFrom(backgroundColor: _isConnected ? Colors.red : Colors.green[700], foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 15)),
//                         child: Text(_isConfiguring ? "AYARLANIYOR..." : (_isConnected ? "BİTİR" : "BAŞLAT")),
//                       ),
//                     ),
//                   ],
//                 ),
//                 const SizedBox(height: 8),
//                 TextField(
//                   onChanged: (value) => _runFilter(value),
//                   decoration: const InputDecoration(
//                     labelText: "Daire veya Seri No Ara",
//                     prefixIcon: Icon(Icons.search),
//                     border: OutlineInputBorder(),
//                     isDense: true,
//                     fillColor: Colors.white,
//                     filled: true,
//                   ),
//                 ),
//               ],
//             ),
//           ),

//           // 2. LİSTE
//           Expanded(
//             flex: 6,
//             child: ListView.builder(
//               itemCount: _filteredJobs.length,
//               itemBuilder: (context, index) {
//                 final job = _filteredJobs[index];
//                 return Card(
//                   color: job.isRead ? Colors.green[50] : Colors.white,
//                   margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
//                   child: ListTile(
//                     dense: true,
//                     leading: CircleAvatar(
//                       backgroundColor: job.isRead ? Colors.green : Colors.grey,
//                       child: Icon(job.isRead ? Icons.check : Icons.timer, color: Colors.white, size: 20),
//                     ),
//                     title: Text(job.location, style: const TextStyle(fontWeight: FontWeight.bold)),
//                     subtitle: Text("SN: ${job.serialNo}"),
//                     trailing: job.isRead
//                         ? Column(
//                             mainAxisAlignment: MainAxisAlignment.center,
//                             crossAxisAlignment: CrossAxisAlignment.end,
//                             children: [
//                               Text(
//                                 "${job.value} m³",
//                                 style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green, fontSize: 16),
//                               ),
//                               const Icon(Icons.signal_wifi_4_bar, color: Colors.green, size: 16),
//                             ],
//                           )
//                         : const Text("-", style: TextStyle(fontSize: 20, color: Colors.grey)),
//                   ),
//                 );
//               },
//             ),
//           ),

//           // 3. LOG (Gizlenebilir)
//           ExpansionTile(
//             title: const Text("Terminal Logları", style: TextStyle(fontSize: 12)),
//             initiallyExpanded: true,
//             onExpansionChanged: (val) => setState(() => _showLogs = val),
//             children: [
//               Container(
//                 height: 120,
//                 color: Colors.black,
//                 width: double.infinity,
//                 child: ListView.builder(
//                   controller: _logScroll,
//                   padding: const EdgeInsets.all(5),
//                   itemCount: _logs.length,
//                   itemBuilder: (context, index) => Text(
//                     _logs[index],
//                     style: TextStyle(color: _logs[index].contains("RX") ? Colors.greenAccent : (_logs[index].contains("TX") ? Colors.yellow : Colors.white), fontFamily: 'Courier', fontSize: 10),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
// }

// // ==============================================================================
// // PARSER (Sihirli Kısım)
// // ==============================================================================
// class ParsedData {
//   String serialNo;
//   double reading;
//   ParsedData({required this.serialNo, required this.reading});
// }

// class RFParser {
//   static ParsedData parse(Uint8List data) {
//     String serialNo = "-";
//     double value = 0.0;
//     try {
//       // 1. Seri No Ara (BCD - Little Endian)
//       for (int i = 0; i < data.length - 4; i++) {
//         String bcd = "";
//         for (var b in data.sublist(i, i + 4).reversed) bcd += b.toRadixString(16).padLeft(2, '0');
//         if (bcd.length == 8 && !bcd.startsWith("0000") && !RegExp(r'[A-F]').hasMatch(bcd)) {
//           serialNo = bcd;
//           break;
//         }
//       }
//       // 2. Değer Ara (0x0C)
//       for (int i = 0; i < data.length - 6; i++) {
//         if (data[i] == 0x0C) {
//           String valStr = "";
//           for (var b in data.sublist(i + 2, i + 6).reversed) valStr += b.toRadixString(16).padLeft(2, '0');
//           value = double.tryParse(valStr) ?? 0.0;
//           if (value > 100) value /= 1000.0;
//           break;
//         }
//       }
//     } catch (e) {}
//     return ParsedData(serialNo: serialNo, reading: value);
//   }
// }
