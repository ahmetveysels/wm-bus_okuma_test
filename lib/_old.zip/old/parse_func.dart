// import 'dart:typed_data';

// import 'package:encrypt/encrypt.dart' as enc;

// // ==========================================
// // 1. DATA MODELS (Veri Modelleri)
// // ==========================================

// /// Okunan verinin türünü belirtir
// enum ReadingType {
//   energy, // Enerji
//   volume, // Hacim (Su)
//   temperature, // Sıcaklık
//   time, // Zaman
//   units, // HCA Birimi
//   unknown, // Bilinmeyen
// }

// /// Tek bir okuma değerini temsil eder (Örn: 123.45 kWh)
// class MeterReading {
//   final double value; // Örn: 123.45
//   final String unit; // Örn: "kWh", "m3", "°C"
//   final ReadingType type; // Örn: ReadingType.energy
//   final String description; // Örn: "Enerji", "Hacim"

//   MeterReading({
//     required this.value,
//     required this.unit,
//     required this.type,
//     required this.description,
//   });

//   @override
//   String toString() => '$description: $value $unit';
// }

// /// Sayaçtan okunan tüm paketi temsil eder
// class MeterData {
//   final String serialNumber;
//   final String manufacturer;
//   final String medium;
//   final int version;
//   final DateTime timestamp;

//   // BURASI DEĞİŞTİ: Artık Map yerine tip güvenli bir liste kullanıyoruz
//   final List<MeterReading> readings;

//   final bool isDecrypted;
//   final String? errorMessage;

//   MeterData({
//     required this.serialNumber,
//     required this.manufacturer,
//     required this.medium,
//     required this.version,
//     required this.timestamp,
//     required this.readings,
//     this.isDecrypted = false,
//     this.errorMessage,
//   });

//   @override
//   String toString() {
//     return 'Sayac: $manufacturer $serialNumber | Okumalar: ${readings.length} adet';
//   }
// }

// // ==========================================
// // 2. UTILS (Yardımcı Araçlar)
// // ==========================================

// class MbusUtils {
//   static String decodeManufacturer(int manCode) {
//     int char1 = ((manCode >> 10) & 0x001F) + 64;
//     int char2 = ((manCode >> 5) & 0x001F) + 64;
//     int char3 = ((manCode) & 0x001F) + 64;
//     return String.fromCharCode(char1) + String.fromCharCode(char2) + String.fromCharCode(char3);
//   }

//   static int decodeBCD(List<int> data) {
//     int val = 0;
//     for (int i = data.length - 1; i >= 0; i--) {
//       val = (val * 100) + ((data[i] >> 4) * 10) + (data[i] & 0x0F);
//     }
//     return val;
//   }

//   static int toInt(List<int> bytes) {
//     int val = 0;
//     for (int i = 0; i < bytes.length; i++) {
//       val |= (bytes[i] << (i * 8));
//     }
//     return val;
//   }

//   static Uint8List hexToBytes(String hex) {
//     hex = hex.replaceAll(" ", "").replaceAll("-", "");
//     List<int> bytes = [];
//     for (int i = 0; i < hex.length; i += 2) {
//       bytes.add(int.parse(hex.substring(i, i + 2), radix: 16));
//     }
//     return Uint8List.fromList(bytes);
//   }

//   static String getMediumString(int mediumCode) {
//     switch (mediumCode) {
//       case 0x04:
//         return "Heat (Isı)";
//       case 0x06:
//         return "Hot Water (Sıcak Su)";
//       case 0x07:
//         return "Water (Su)";
//       case 0x08:
//         return "HCA (Isı Pay Ölçer)";
//       case 0x16:
//         return "Cold Water (Soğuk Su)";
//       default:
//         return "Unknown (0x${mediumCode.toRadixString(16)})";
//     }
//   }
// }

// // ==========================================
// // 3. DECRYPTER (Şifre Çözücü)
// // ==========================================

// class WMBusDecrypter {
//   static Uint8List? decryptMode5(Uint8List payload, Uint8List key, Uint8List iv) {
//     try {
//       final keyParam = enc.Key(key);
//       final ivParam = enc.IV(iv);

//       final encrypter = enc.Encrypter(
//         enc.AES(keyParam, mode: enc.AESMode.cbc, padding: null),
//       );

//       final decrypted = encrypter.decryptBytes(enc.Encrypted(payload), iv: ivParam);

//       if (decrypted.length > 2 && decrypted[0] == 0x2F && decrypted[1] == 0x2F) {
//         return Uint8List.fromList(decrypted);
//       }
//       return Uint8List.fromList(decrypted);
//     } catch (e) {
//       return null;
//     }
//   }

//   static Uint8List generateIV(List<int> manufacturer, List<int> id, int version, int medium, int accessNo) {
//     List<int> iv = [];
//     iv.addAll(manufacturer);
//     iv.addAll(id);
//     iv.add(version);
//     iv.add(medium);
//     for (int i = 0; i < 8; i++) {
//       iv.add(accessNo);
//     }
//     return Uint8List.fromList(iv);
//   }
// }

// // ==========================================
// // 4. PARSER (Ana Mantık)
// // ==========================================

// class WMBusParser {
//   final List<String> aesKeys;

//   WMBusParser(this.aesKeys);

//   MeterData? parseFrame(List<int> rawData) {
//     if (rawData.length < 15) return null;

//     int offset = 0;
//     // L ve C field geçildi varsayımı (USB stick'e göre değişebilir)
//     offset += 2;

//     // Header Parsing
//     int manCode = MbusUtils.toInt(rawData.sublist(offset, offset + 2));
//     String manufacturer = MbusUtils.decodeManufacturer(manCode);
//     offset += 2;

//     List<int> idBytes = rawData.sublist(offset, offset + 4);
//     String serialNumber = idBytes.reversed.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
//     offset += 4;

//     int version = rawData[offset++];
//     int medium = rawData[offset++];
//     int ciField = rawData[offset++];

//     // Şifreleme Kontrolleri
//     int accessNo = 0;
//     int encryptionMode = 0;

//     if (ciField == 0x7A) {
//       // Short Header
//       accessNo = rawData[offset++];
//       int status = rawData[offset++];
//       int config = rawData[offset++];
//       encryptionMode = (config & 0x0F);
//       offset++;
//     } else if (ciField == 0x72) {
//       // Long Header
//       offset += 8;
//       accessNo = rawData[offset++];
//       offset++; // Status
//       int config = rawData[offset++];
//       encryptionMode = (config & 0x0F);
//       offset++;
//     }

//     // Payload Hazırlığı
//     List<int> payload = rawData.sublist(offset);
//     List<int> processedPayload = List.from(payload);
//     bool isDecrypted = false;

//     // Decryption
//     if (encryptionMode == 5) {
//       Uint8List iv = WMBusDecrypter.generateIV(rawData.sublist(2, 4), rawData.sublist(4, 8), version, medium, accessNo);

//       for (String keyHex in aesKeys) {
//         Uint8List key = MbusUtils.hexToBytes(keyHex);
//         Uint8List? result = WMBusDecrypter.decryptMode5(Uint8List.fromList(payload), key, iv);

//         if (result != null) {
//           processedPayload = result;
//           isDecrypted = true;
//           break;
//         }
//       }
//     } else if (encryptionMode == 0) {
//       isDecrypted = true;
//     }

//     // --- BURASI DEĞİŞTİ: Model Listesi Olarak Parse Et ---
//     List<MeterReading> readings = [];
//     if (isDecrypted) {
//       readings = _parseDataRecords(processedPayload);
//     }

//     return MeterData(
//       serialNumber: serialNumber,
//       manufacturer: manufacturer,
//       medium: MbusUtils.getMediumString(medium),
//       version: version,
//       timestamp: DateTime.now(),
//       readings: readings, // Map yerine List<MeterReading>
//       isDecrypted: isDecrypted,
//       errorMessage: isDecrypted ? null : "Şifre çözülemedi",
//     );
//   }

//   /// DIF/VIF kayıtlarını MeterReading modeline çeviren fonksiyon
//   List<MeterReading> _parseDataRecords(List<int> data) {
//     List<MeterReading> results = [];
//     int i = 0;

//     // Idle filler (0x2F) atla
//     while (i < data.length && data[i] == 0x2F) {
//       i++;
//     }

//     while (i < data.length) {
//       if (i >= data.length) break;

//       int dif = data[i++];
//       if (dif == 0x0F || dif == 0x1F) {
//         i++;
//         continue;
//       }

//       int dataLength = 0;
//       String typeStr = "";

//       // DIF Analizi (Veri Uzunluğu ve Tipi)
//       int difDataField = dif & 0x0F;
//       switch (difDataField) {
//         case 0x00:
//           dataLength = 0;
//           break;
//         case 0x01:
//           dataLength = 1;
//           typeStr = "Int";
//           break;
//         case 0x02:
//           dataLength = 2;
//           typeStr = "Int";
//           break;
//         case 0x03:
//           dataLength = 3;
//           typeStr = "Int";
//           break;
//         case 0x04:
//           dataLength = 4;
//           typeStr = "Int";
//           break;
//         case 0x05:
//           dataLength = 4;
//           typeStr = "Float";
//           break; // Float32
//         case 0x06:
//           dataLength = 6;
//           typeStr = "Int";
//           break;
//         case 0x07:
//           dataLength = 8;
//           typeStr = "Int";
//           break;
//         case 0x0D: // Variable length string
//           if (i < data.length) dataLength = data[i++];
//           typeStr = "String";
//           break;
//         case 0x09:
//           dataLength = 1;
//           typeStr = "BCD";
//           break;
//         case 0x0A:
//           dataLength = 2;
//           typeStr = "BCD";
//           break;
//         case 0x0B:
//           dataLength = 3;
//           typeStr = "BCD";
//           break;
//         case 0x0C:
//           dataLength = 4;
//           typeStr = "BCD";
//           break;
//         default:
//           return results;
//       }

//       // VIF Analizi (Birim ve Çarpan)
//       if (i >= data.length) break;
//       int vif = data[i++];

//       String description = "Veri";
//       String unit = "";
//       double multiplier = 1.0;
//       ReadingType readingType = ReadingType.unknown;

//       // --- VIF TABLOSU (Genişletilmiş) ---

//       // Enerji (Wh) - E000 0xxx
//       if ((vif & 0x78) == 0x00) {
//         description = "Enerji";
//         unit = "Wh";
//         readingType = ReadingType.energy;
//         multiplier = 0.001 * (1 << (vif & 0x07)); // 10^(x-3)
//       }
//       // Enerji (kWh) - E000 0xxx (0x06 yaygın kullanımdır)
//       else if (vif == 0x06) {
//         description = "Enerji";
//         unit = "kWh";
//         readingType = ReadingType.energy;
//         multiplier = 1.0;
//       }
//       // Hacim (m3) - E001 0xxx
//       else if ((vif & 0x78) == 0x10) {
//         description = "Hacim";
//         unit = "m³";
//         readingType = ReadingType.volume;
//         // VIF 0x13 -> 10^-3 = 0.001
//         // VIF 0x14 -> 10^-2 = 0.01
//         multiplier = 0.001 * (1 << ((vif & 0x07) - 3 + 3)); // Basit üs hesabı, kontrollü
//         if (vif == 0x13) multiplier = 0.001;
//         if (vif == 0x14) multiplier = 0.01;
//         if (vif == 0x15) multiplier = 0.1;
//         if (vif == 0x16) multiplier = 1.0;
//       }
//       // HCA (Isı Pay Ölçer Birimi)
//       else if (vif == 0x6E) {
//         description = "Tüketim";
//         unit = "HCA";
//         readingType = ReadingType.units;
//       }
//       // Sıcaklık (Flow)
//       else if (vif == 0x5A) {
//         // Flow Temp
//         description = "Giriş Sıcaklığı";
//         unit = "°C";
//         readingType = ReadingType.temperature;
//         multiplier = 0.1; // Genelde BCD ondalıklı gelir
//       }
//       // Sıcaklık (Return)
//       else if (vif == 0x5E) {
//         // Return Temp
//         description = "Dönüş Sıcaklığı";
//         unit = "°C";
//         readingType = ReadingType.temperature;
//         multiplier = 0.1;
//       }
//       // Zaman
//       else if (vif == 0x6D) {
//         description = "Zaman";
//         unit = "";
//         readingType = ReadingType.time;
//       } else {
//         description = "Bilinmeyen (VIF: ${vif.toRadixString(16)})";
//       }

//       // VIFE (Extension) varsa atla (Implementasyon basitliği için)
//       if ((vif & 0x80) != 0) {
//         while (i < data.length && (data[i] & 0x80) != 0) i++;
//         i++;
//       }

//       // Değeri Okuma
//       if (i + dataLength > data.length) break;
//       List<int> valueBytes = data.sublist(i, i + dataLength);
//       i += dataLength;

//       // Sadece sayısal değerleri listeye ekle
//       if (typeStr != "String" && readingType != ReadingType.time) {
//         double rawVal = 0;
//         if (typeStr == "BCD") {
//           rawVal = MbusUtils.decodeBCD(valueBytes).toDouble();
//         } else if (typeStr == "Float") {
//           // Float dönüşümü için ByteData kullanmak gerekebilir, şimdilik Int gibi alıp geçiyoruz
//           // M-Bus Float formatı standart IEEE 754'tür.
//           rawVal = MbusUtils.toInt(valueBytes).toDouble();
//         } else {
//           rawVal = MbusUtils.toInt(valueBytes).toDouble();
//         }

//         double finalValue = rawVal * multiplier;

//         // Model Listesine Ekle
//         results.add(
//           MeterReading(
//             value: double.parse(finalValue.toStringAsFixed(3)), // 3 hane hassasiyet
//             unit: unit,
//             type: readingType,
//             description: description,
//           ),
//         );
//       }
//     }
//     return results;
//   }
// }

// // ==========================================
// // 5. TEST
// // ==========================================
// void main() {
//   List<String> myKeys = ["51728910E66D83F851728910E66D83F8"];
//   final parser = WMBusParser(myKeys);
//   // Örnek boş veri (Gerçek senaryoda burası dolu olmalı)
//   print("Parser hazır.");
// }
